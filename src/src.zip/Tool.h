// Tool.h
#pragma once

enum class Tool {
    None,
    View,
    Flick,
    Grab,
    Select,
    Pencil,
    Eraser
};
